def test():
    print("Test")
    return ("Test!")



