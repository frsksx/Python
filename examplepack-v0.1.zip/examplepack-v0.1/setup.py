
from setuptools import setup

setup(name='examplepack',
      version='0.1',
      description='',
      author='',
      author_email='',
      license='',
      packages=['examplepack'],
      zip_safe=False)
